import sqlite3, os, csv, io, random
from datetime import date, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, g, Response
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "change-this-secret"
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "attendance.db")
LOW = 75  # low-attendance threshold (%)

SCHEMA = """
CREATE TABLE IF NOT EXISTS departments(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS classes(id INTEGER PRIMARY KEY, name TEXT NOT NULL, department_id INTEGER NOT NULL REFERENCES departments(id), UNIQUE(name, department_id));
CREATE TABLE IF NOT EXISTS subjects(id INTEGER PRIMARY KEY, name TEXT NOT NULL, class_id INTEGER NOT NULL REFERENCES classes(id), UNIQUE(name, class_id));
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin','teacher')), department_id INTEGER REFERENCES departments(id));
CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, roll_no TEXT UNIQUE NOT NULL, name TEXT NOT NULL, email TEXT, phone TEXT, class_id INTEGER NOT NULL REFERENCES classes(id));
CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    subject_id INTEGER NOT NULL REFERENCES subjects(id), date TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('Present','Absent')),
    marked_by INTEGER REFERENCES users(id), UNIQUE(student_id, subject_id, date));
"""

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close(_):
    d = g.pop("db", None)
    if d: d.close()

def init_db():
    c = sqlite3.connect(DB); c.executescript(SCHEMA)
    if not c.execute("SELECT 1 FROM users").fetchone():
        c.executemany("INSERT INTO departments(name) VALUES(?)", [("Computer Science",), ("Commerce",)])
        c.executemany("INSERT INTO classes(name,department_id) VALUES(?,?)", [("BSc CS - Year 1", 1), ("BSc CS - Year 2", 1), ("BCom - Year 1", 2)])
        subs = {1: ["Programming", "Mathematics", "English"], 2: ["Data Structures", "DBMS", "Networks"], 3: ["Accounting", "Economics", "Business Law"]}
        for cid, names in subs.items():
            c.executemany("INSERT INTO subjects(name,class_id) VALUES(?,?)", [(n, cid) for n in names])
        c.execute("INSERT INTO users(name,username,password,role) VALUES('Administrator','admin',?,'admin')", (generate_password_hash("admin123"),))
        c.execute("INSERT INTO users(name,username,password,role,department_id) VALUES('Ms. Kavitha','teacher',?,'teacher',1)", (generate_password_hash("teacher123"),))
        names = ["Aarav Kumar", "Divya Lakshmi", "Harish Raj", "Ishwarya S", "Karthik M", "Meena P", "Naveen R", "Oviya T", "Pranav V", "Revathi K", "Sanjay D", "Thenmozhi A"]
        for i, n in enumerate(names):
            c.execute("INSERT INTO students(roll_no,name,email,phone,class_id) VALUES(?,?,?,?,?)",
                      (f"R{100+i}", n, n.split()[0].lower() + "@example.com", "98765432%02d" % i, i % 3 + 1))
        random.seed(1); day, done = date.today(), 0
        while done < 10:
            if day.weekday() < 5:
                for sid in range(1, 13):
                    cid = (sid - 1) % 3 + 1; p = 0.5 if sid in (4, 8) else 0.85
                    for sub in c.execute("SELECT id FROM subjects WHERE class_id=?", (cid,)).fetchall():
                        c.execute("INSERT INTO attendance(student_id,subject_id,date,status,marked_by) VALUES(?,?,?,?,2)",
                                  (sid, sub[0], day.isoformat(), "Present" if random.random() < p else "Absent"))
                done += 1
            day -= timedelta(days=1)
    c.commit(); c.close()

@app.before_request
def load_user():
    g.user = db().execute("SELECT * FROM users WHERE id=?", (session.get("uid"),)).fetchone() if session.get("uid") else None

def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user: return redirect(url_for("login"))
        return f(*a, **k)
    return w

def admin_required(f):
    @wraps(f)
    @login_required
    def w(*a, **k):
        if g.user["role"] != "admin":
            flash("Only the admin can open that page.", "error"); return redirect(url_for("dashboard"))
        return f(*a, **k)
    return w

def stats(class_id=None, subject_id=None, d_from=None, d_to=None, q=None):
    """Per-student attendance totals and percentage, with optional filters."""
    on, p, where, wp = ["a.student_id=s.id"], [], ["1=1"], []
    if subject_id: on.append("a.subject_id=?"); p.append(subject_id)
    if d_from: on.append("a.date>=?"); p.append(d_from)
    if d_to: on.append("a.date<=?"); p.append(d_to)
    if class_id: where.append("s.class_id=?"); wp.append(class_id)
    if q: where.append("(s.name LIKE ? OR s.roll_no LIKE ?)"); wp += [f"%{q}%"] * 2
    sql = f"""SELECT s.id, s.roll_no, s.name, c.name AS class_name, COUNT(a.id) AS total, COALESCE(SUM(a.status='Present'),0) AS present
              FROM students s JOIN classes c ON c.id=s.class_id LEFT JOIN attendance a ON {' AND '.join(on)}
              WHERE {' AND '.join(where)} GROUP BY s.id ORDER BY s.roll_no"""
    rows = []
    for r in db().execute(sql, p + wp):
        d = dict(r); d["pct"] = round(100 * d["present"] / d["total"], 1) if d["total"] else None
        d["low"] = d["pct"] is not None and d["pct"] < LOW; rows.append(d)
    return rows

def datewise(class_id, subject_id, d_from, d_to):
    where, p = ["1=1"], []
    if class_id: where.append("s.class_id=?"); p.append(class_id)
    if subject_id: where.append("a.subject_id=?"); p.append(subject_id)
    if d_from: where.append("a.date>=?"); p.append(d_from)
    if d_to: where.append("a.date<=?"); p.append(d_to)
    return db().execute(f"""SELECT a.date, COUNT(*) AS total, SUM(a.status='Present') AS present FROM attendance a
        JOIN students s ON s.id=a.student_id WHERE {' AND '.join(where)} GROUP BY a.date ORDER BY a.date DESC""", p).fetchall()

def lookups():
    d = db()
    return dict(depts=d.execute("SELECT * FROM departments ORDER BY name").fetchall(), classes=d.execute("SELECT * FROM classes ORDER BY name").fetchall(),
                subjects=d.execute("SELECT * FROM subjects ORDER BY name").fetchall())

@app.route("/")
def index(): return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = db().execute("SELECT * FROM users WHERE username=? AND role=?", (request.form["username"].strip(), request.form["role"])).fetchone()
        if u and check_password_hash(u["password"], request.form["password"]):
            session["uid"] = u["id"]; return redirect(url_for("dashboard"))
        flash("Wrong username, password or role.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    rows = stats(); rec = sum(r["total"] for r in rows); pres = sum(r["present"] for r in rows)
    latest = db().execute("SELECT MAX(date) m FROM attendance").fetchone()["m"]
    day = db().execute("SELECT COALESCE(SUM(status='Present'),0) p, COALESCE(SUM(status='Absent'),0) a FROM attendance WHERE date=?", (latest,)).fetchone() if latest else None
    by_class = db().execute("""SELECT c.name, ROUND(100.0*SUM(a.status='Present')/COUNT(a.id),1) AS pct FROM classes c
        JOIN students s ON s.class_id=c.id JOIN attendance a ON a.student_id=s.id GROUP BY c.id""").fetchall()
    return render_template("dashboard.html", total=len(rows), avg=round(100 * pres / rec, 1) if rec else 0, latest=latest, day=day,
        low=[r for r in rows if r["low"]], chart=dict(present=pres, absent=rec - pres, labels=[r["name"] for r in by_class], values=[r["pct"] for r in by_class]))

@app.route("/students")
@login_required
def students():
    cid, q = request.args.get("class_id") or None, request.args.get("q", "").strip()
    return render_template("students.html", rows=stats(class_id=cid, q=q), cid=cid, q=q, **lookups())

@app.route("/students/add", methods=["GET", "POST"])
@login_required
def add_student():
    if request.method == "POST":
        f = {k: request.form.get(k, "").strip() for k in ("roll_no", "name", "email", "phone", "class_id")}
        if not (f["roll_no"] and f["name"] and f["class_id"]) or (f["phone"] and not (f["phone"].isdigit() and len(f["phone"]) >= 10)):
            flash("Roll number, name and class are required. A phone number needs 10+ digits.", "error")
        else:
            try:
                db().execute("INSERT INTO students(roll_no,name,email,phone,class_id) VALUES(?,?,?,?,?)", tuple(f.values()))
                db().commit(); flash("Student registered.", "ok"); return redirect(url_for("students"))
            except sqlite3.IntegrityError:
                flash("That roll number is already registered.", "error")
    return render_template("add_student.html", **lookups())

@app.route("/students/<int:sid>")
@login_required
def student(sid):
    s = db().execute("SELECT s.*, c.name AS class_name FROM students s JOIN classes c ON c.id=s.class_id WHERE s.id=?", (sid,)).fetchone()
    if not s: return render_template("error.html", msg="Student not found."), 404
    per_subject = db().execute("""SELECT sub.name, COUNT(a.id) total, COALESCE(SUM(a.status='Present'),0) present FROM subjects sub
        LEFT JOIN attendance a ON a.subject_id=sub.id AND a.student_id=? WHERE sub.class_id=? GROUP BY sub.id""", (sid, s["class_id"])).fetchall()
    history = db().execute("SELECT a.date, sub.name AS subject, a.status FROM attendance a JOIN subjects sub ON sub.id=a.subject_id WHERE a.student_id=? ORDER BY a.date DESC, sub.name LIMIT 60", (sid,)).fetchall()
    return render_template("student.html", s=s, per_subject=per_subject, history=history, overall=stats(q=s["roll_no"])[0])

@app.route("/students/<int:sid>/delete", methods=["POST"])
@admin_required
def delete_student(sid):
    db().execute("DELETE FROM students WHERE id=?", (sid,)); db().commit(); flash("Student removed.", "ok")
    return redirect(url_for("students"))

@app.route("/attendance", methods=["GET", "POST"])
@login_required
def attendance():
    a = request.form if request.method == "POST" else request.args
    cid, sid, day = a.get("class_id") or None, a.get("subject_id") or None, a.get("date") or date.today().isoformat()
    try: date.fromisoformat(day)
    except ValueError: flash("Choose a valid date.", "error"); day = date.today().isoformat(); cid = sid = None
    rows, marked = [], {}
    if cid and sid:
        if not db().execute("SELECT 1 FROM subjects WHERE id=? AND class_id=?", (sid, cid)).fetchone():
            flash("That subject does not belong to the selected class.", "error"); cid = sid = None
        else:
            rows = db().execute("SELECT * FROM students WHERE class_id=? ORDER BY roll_no", (cid,)).fetchall()
            if request.method == "POST":
                for s in rows:  # UNIQUE(student, subject, date) + upsert prevents duplicates
                    db().execute("""INSERT INTO attendance(student_id,subject_id,date,status,marked_by) VALUES(?,?,?,?,?)
                        ON CONFLICT(student_id,subject_id,date) DO UPDATE SET status=excluded.status, marked_by=excluded.marked_by""",
                        (s["id"], sid, day, "Present" if request.form.get(f"s{s['id']}") == "Present" else "Absent", g.user["id"]))
                db().commit(); flash(f"Attendance saved for {len(rows)} students on {day}.", "ok")
                return redirect(url_for("attendance", class_id=cid, subject_id=sid, date=day))
            marked = {r["student_id"]: r["status"] for r in db().execute("SELECT student_id,status FROM attendance WHERE subject_id=? AND date=?", (sid, day))}
    return render_template("attendance.html", rows=rows, marked=marked, cid=cid, sid=sid, day=day, today=date.today().isoformat(), **lookups())

def report_args():
    a = request.args
    return dict(class_id=a.get("class_id") or None, subject_id=a.get("subject_id") or None, d_from=a.get("from") or None, d_to=a.get("to") or None)

@app.route("/reports")
@login_required
def reports():
    p = report_args(); rows = stats(**p)
    return render_template("reports.html", rows=rows, days=datewise(**p), p=p, low=sum(r["low"] for r in rows), **lookups())

@app.route("/reports/download")
@login_required
def download():
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["Roll No", "Name", "Class", "Total classes", "Present", "Absent", "Percentage", "Status"])
    for r in stats(**report_args()):
        w.writerow([r["roll_no"], r["name"], r["class_name"], r["total"], r["present"], r["total"] - r["present"],
                    "" if r["pct"] is None else r["pct"], "No records" if r["pct"] is None else ("Low" if r["low"] else "OK")])
    return Response(out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=attendance_report.csv"})

@app.route("/manage", methods=["GET", "POST"])
@admin_required
def manage():
    if request.method == "POST":
        f, t = request.form, request.form.get("form_type")
        try:
            if t == "department": db().execute("INSERT INTO departments(name) VALUES(?)", (f["name"].strip(),))
            elif t == "class": db().execute("INSERT INTO classes(name,department_id) VALUES(?,?)", (f["name"].strip(), f["department_id"]))
            elif t == "subject": db().execute("INSERT INTO subjects(name,class_id) VALUES(?,?)", (f["name"].strip(), f["class_id"]))
            elif t == "teacher":
                if len(f["password"]) < 6: raise ValueError("The password needs at least 6 characters.")
                db().execute("INSERT INTO users(name,username,password,role,department_id) VALUES(?,?,?,'teacher',?)",
                             (f["name"].strip(), f["username"].strip(), generate_password_hash(f["password"]), f["department_id"] or None))
            db().commit(); flash("Saved.", "ok")
        except sqlite3.IntegrityError: flash("That name or username already exists.", "error")
        except (ValueError, KeyError) as e: flash(str(e) if isinstance(e, ValueError) else "Fill in every field.", "error")
        return redirect(url_for("manage"))
    teachers = db().execute("SELECT u.*, d.name AS dept FROM users u LEFT JOIN departments d ON d.id=u.department_id WHERE role='teacher'").fetchall()
    cls = db().execute("SELECT c.*, d.name AS dept FROM classes c JOIN departments d ON d.id=c.department_id ORDER BY d.name, c.name").fetchall()
    return render_template("manage.html", teachers=teachers, cls=cls, **lookups())

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        if not check_password_hash(g.user["password"], request.form["current"]): flash("Current password is wrong.", "error")
        elif len(request.form["new"]) < 6: flash("The new password needs at least 6 characters.", "error")
        else:
            db().execute("UPDATE users SET password=? WHERE id=?", (generate_password_hash(request.form["new"]), g.user["id"]))
            db().commit(); flash("Password changed.", "ok")
    return render_template("profile.html")

@app.errorhandler(404)
def nf(e): return render_template("error.html", msg="Page not found."), 404

@app.errorhandler(500)
def se(e): return render_template("error.html", msg="Something went wrong on our side. Try again."), 500

init_db()
if __name__ == "__main__":
    app.run(debug=True)
