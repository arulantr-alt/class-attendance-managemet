# Web-Based Class Attendance Management System
Flask + SQLite + Bootstrap 5. Teachers mark Present/Absent by class, subject and date; admins manage departments, classes, subjects and teachers.
Percentages, low-attendance alerts (below 75%), dashboard charts and CSV reports are built in.

## Run in VS Code on Windows
1. Install Python 3.10+ from python.org (tick "Add Python to PATH").
2. In VS Code choose File > Open Folder and pick `ClassAttendance`, then open a terminal with Ctrl+`.
3. Create and activate a virtual environment:
   ```
   python -m venv venv
   venv\Scripts\activate
   ```
   (If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once.)
4. Install Flask: `pip install -r requirements.txt`
5. Start the app: `python app.py`
6. Open http://127.0.0.1:5000

The database (`attendance.db`) and sample data are created on the first run. To reset, stop the app and delete `attendance.db`.

## Demo logins
- Admin: `admin` / `admin123`
- Teacher: `teacher` / `teacher123`

The pages load Bootstrap and Chart.js from a CDN, so you need an internet connection.
