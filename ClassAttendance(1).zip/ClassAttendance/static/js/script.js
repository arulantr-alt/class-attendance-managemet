// Bootstrap form validation
document.querySelectorAll(".needs-validation").forEach(f => f.addEventListener("submit", e => {
  if (!f.checkValidity()) { e.preventDefault(); f.classList.add("was-validated"); }
}));

// Cascading department -> class -> subject selects
const dept = document.getElementById("dept"), cls = document.getElementById("class_id"), sub = document.getElementById("subject_id");
function filt(sel, attr, val) {
  [...sel.options].forEach(o => { if (!o.value) return; const ok = !val || o.dataset[attr] === val; o.hidden = !ok; o.disabled = !ok; });
  if (sel.selectedOptions[0] && sel.selectedOptions[0].disabled) sel.value = "";
}
if (cls && sub && sub.querySelector("[data-class]")) {
  if (dept && cls.value && !dept.value) dept.value = cls.selectedOptions[0].dataset.dept || "";
  if (dept) filt(cls, "dept", dept.value);
  filt(sub, "class", cls.value);
  if (dept) dept.onchange = () => { filt(cls, "dept", dept.value); filt(sub, "class", cls.value); };
  cls.onchange = () => filt(sub, "class", cls.value);
}

// Mark all buttons on the attendance sheet
const mark = v => () => document.querySelectorAll("#markform input[value=" + v + "]").forEach(i => i.checked = true);
if (document.getElementById("allP")) { allP.onclick = mark("Present"); allA.onclick = mark("Absent"); }
